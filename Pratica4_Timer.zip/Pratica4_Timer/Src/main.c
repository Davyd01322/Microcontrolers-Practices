#include <stdint.h>

#if !defined(__SOFT_FP__) && defined(__ARM_FP)
  #warning "FPU is not initialized, but the project is compiling for an FPU. Please initialize the FPU before use."
#endif

#include "stm32f1xx.h"

static volatile int led_9 = 0;

void TIM2_IRQHandler(void){
	if(TIM2->SR & TIM_SR_UIF){
		if(led_9 == 0){
			// Set the pin 9
			GPIOB->BSRR = (1 << 9);
			led_9 = 1;
		} else{
			// Clear the pin 9
			GPIOB->BSRR = (1 << 25);
			led_9 = 0;
		}

		// Clears the interruption flag
		TIM2->SR = 0;
	}
}

int main(void){
	// Set Bit 3 to enable GPIOB clock
	RCC->APB2ENR |= (1 << 3);
	// Enable clock access to timer2
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

	// Make GPIOB Pin8 and Pin9 output
	GPIOB->CRH &= 0xFFFFFF00;
	GPIOB->CRH |= 0x00000022;

	// Reset GPIOB Pin8 and Pin9
	GPIOB->ODR &= ~((1 << 9) | (1 << 8));

	// Configure timer2
	TIM2->CR1 |= TIM_CR1_CEN;
	TIM2->PSC = 7200-1;
	TIM2->ARR = 1000-1;
	TIM2->EGR |= TIM_EGR_UG;
	TIM2->CNT = 0;

	/* Set UIE(Update interrupt enable) bit
	 * in TIMx DMA/Interrupt enable register (TIMx_DIER)
	 * to enable timer interrupt*/
	TIM2->DIER |= TIM_DIER_UIE;

	// Enable timer2 interrupt in NVIC
	NVIC_EnableIRQ(TIM2_IRQn);

	while(1){
		if(TIM2->CNT > 500){
			GPIOB->BSRR = (1 << 8);
			if(TIM2->CNT > 550){
				GPIOB->BSRR = (1 << 24);
			}
		}
	}
}

