#include <stdint.h>
#include "stm32f1xx.h"

int led13 = 0;

void TIM2_IRQHandler(void){
	if(TIM2->SR & (1 << 0)){
		if(led13){
			GPIOC->ODR &= ~(0x00002000);
			led13 = 0;
		}
		else{
			GPIOC->ODR |= (0x00002000);
			led13 = 1;
		}
		TIM2->SR &= ~(1 << 0);
	}
}

int main(void){
	RCC->APB2ENR |= (1 << 4);
	GPIOC->CRH &= 0xFF0FFFFF;
	GPIOC->CRH |= 0x00200000;

	// Ligar o clock do Timer2
	RCC->APB1ENR |= (1 << 0);

	/* Configuração do timer 2 */
	TIM2->PSC = 8000 - 1;
	// Contar até mil (dura 1 segundo)
	TIM2->ARR = 1000 - 1;

	// Habilitar a interrupção
	// Bit 0 UG: Update generation
	// 1: Re-initialize the counter and generates an update of the registers.
	TIM2->EGR |= (1 << 0);

	// Habilitar a interrupção
	TIM2->DIER |= (1 << 0);

	// Fazer o nvic aceitar essa interrupção
	NVIC_EnableIRQ(TIM2_IRQn);

	// Ligar o contador
	TIM2->CR1 |= (1 << 0);

	while(1){
		// 5.3.3 Sleep mode
		// The Sleep mode is entered by executing the WFI (Wait For Interrupt)
		// or WFE (Wait for Event) instructions.

		__WFI();
	}
}
