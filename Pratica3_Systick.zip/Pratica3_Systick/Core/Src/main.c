#include "main.h"

#define SYSTICK_LOAD (SystemCoreClock/1000000U)
#define SYSTICK_DELAY_CALIB (SYSTICK_LOAD >> 1)

#define DELAY_US(us)\
	do{\
		uint32_t start = SysTick->VAL;\
		uint32_t ticks = (us*SYSTICK_LOAD) - SYSTICK_DELAY_CALIB;\
		while((start - SysTick->VAL) < ticks);\
	}while(0)

#define DELAY_MS(ms)\
	do{\
		for(uint32_t i = 0; i < ms; i++){\
			DELAY_US(1000);\
		}\
	}while(0)

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
int main(void){
	HAL_Init();
	SystemClock_Config();
    MX_GPIO_Init();

    while (1){
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);

    	DELAY_MS(1000);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 1);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);

    	DELAY_MS(1000);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);

    	DELAY_MS(1000);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 1);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);

    	DELAY_MS(1000);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, 0);
    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 1);

    	DELAY_MS(1000);

    }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : PB6 PB7 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
